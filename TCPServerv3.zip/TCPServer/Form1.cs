﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using SuperSimpleTcp;
using static System.Net.Mime.MediaTypeNames;

namespace TCPServer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string[] clients = new string[0];
        string[] Nick_clients = new string[0];
        SimpleTcpServer server;
        private void Form1_Load(object sender, EventArgs e)
        {
            button2.Enabled = false;
            button1.Enabled = false;
            server = new SimpleTcpServer("127.0.0.1:8888");
            server.Events.ClientConnected += Events_ClientConnected;
            server.Events.ClientDisconnected += Events_ClientDisconnected;
            server.Events.DataReceived += Events_DataReceived;

        }

        private void Events_DataReceived(object sender, DataReceivedEventArgs e)
        {
            this.Invoke((MethodInvoker)delegate
            {
                string Decoderdata = Encoding.UTF8.GetString(e.Data.Array, 0, e.Data.Count);
                string DnPush = e.IpPort;
                if (Decoderdata.EndsWith("/"))
                {
                    string NickNameArc = Decoderdata.Substring(0, Decoderdata.IndexOf('/'));
                    if (Nick_clients.Contains(NickNameArc)) { server.Send(e.IpPort, "Никнейм уже занят");server.DisconnectClient(e.IpPort);}
                    else { Nick_clients = Nick_clients.Append(NickNameArc).ToArray();
                        IPClient.Items.Add(NickNameArc);
                        Online();
                    }

                }
                else
                {
                    string NickName = Decoderdata.Substring(0, Decoderdata.IndexOf('/'));
                    textBox2.Text += $"{NickName}:{Decoderdata.Substring(Decoderdata.IndexOf('/') + 1)}{Environment.NewLine}";
                    for (int i = 0; i < clients.Length; i++)
                    {
                        if (DnPush != clients[i])
                            server.Send($"{clients[i]}", NickName + ":" + Decoderdata.Substring(Decoderdata.IndexOf('/') + 1));
                    }
                }
            });
        }
       
        private void Events_ClientDisconnected(object sender, ConnectionEventArgs e)
        {
            this.Invoke((MethodInvoker)delegate
            {
                textBox2.Text += $"{e.IpPort} DISCONNECTED. {Environment.NewLine}";
                int index= 0;
                for (int i = 0; i < clients.Length; i++)
                {
                    if (clients[i] == e.IpPort) { index = i; }
                }
                clients = clients.Where(val => val != Convert.ToString(e.IpPort)).ToArray();
                Online();
                for (int i = 0; i < Nick_clients.Length; i++)
                {
                    if (index == i) { IPClient.Items.Remove(Convert.ToString(Nick_clients[i]));
                        Nick_clients = Nick_clients.Where(val => val != Convert.ToString(Nick_clients[i])).ToArray();
                    }
                }
                Online();
            });
        }

        private void Events_ClientConnected(object sender, ConnectionEventArgs e)
        {
            this.Invoke((MethodInvoker)delegate
                {
                    textBox2.Text += $"{e.IpPort} CONNECTED. {Environment.NewLine}";
                    clients = clients.Append(Convert.ToString(e.IpPort)).ToArray();
                });
        }

        private void button3_Click(object sender, EventArgs e)
        {
            server.Start();
            textBox2.Text += $"Starting server...{Environment.NewLine}";
            button3.Enabled = false;
            button2.Enabled = true;
            button1.Enabled = true;
            button4.Enabled = true;
        }
        async Task Online()
        {
            await Task.Run(() =>
            {
                for (int i = 0; i < clients.Length; i++)
                {
                  server.SendAsync(clients[i],"!");
                }
                for (int i=0;i<clients.Length;i++)
                {
                    for(int j=0; j < Nick_clients.Length;j++) {
                        server.SendAsync(clients[i],Nick_clients[j]+"/");
                    }
                }
            });
        }
        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                var strWithoutSpaces = textBox3.Text.Replace(" ", "");
                if (strWithoutSpaces != "")
                {
                    for (int i = 0; i < clients.Length; i++)
                    {
                        server.Send($"{clients[i]}", "Server:" + textBox3.Text);
                    }
                    textBox2.Text += $"Server:{textBox3.Text}{Environment.NewLine}";
                }
                textBox3.Text = string.Empty;
            }
            catch { textBox2.Text += $"Sending error...{Environment.NewLine}"; }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void IPClient_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                textBox2.Text += $"Подключенные клиенты:{clients.Length}{Environment.NewLine}";
                for (int i = 0; i < clients.Length; i++)
                {
                    textBox2.Text += $"{Nick_clients[i]}{Environment.NewLine}";
                }
            }
            catch { textBox2.Text += $"error...{Environment.NewLine}"; }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < clients.Length; i++)
            {
                server.DisconnectClient(clients[i]);
            }
            server.Stop();
            textBox2.Text += $"Stop server...{Environment.NewLine}";
            button4.Enabled = false;
            button3.Enabled = true;
            button2.Enabled = false;
            button1.Enabled = false;
        }
    }
}
