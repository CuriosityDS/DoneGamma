﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SuperSimpleTcp;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace TCPClient
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }
        SimpleTcpClient client;
        public int uif { get; set; }
        public string Nickname { get; set; }
        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                var strWithoutSpaces = textBox3.Text.Replace(" ", "");
                if (strWithoutSpaces != "" && client.IsConnected)
                {
                    client.SendAsync(Nickname + "#" + uif +"/" + textBox3.Text);
                    textBox2.Text += $"Me:{textBox3.Text}{Environment.NewLine}";
                    textBox3.Text = string.Empty;
                }
            } catch { textBox2.Text += $"Sending error...{Environment.NewLine}"; }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            Random rnd = new Random();
            uif = rnd.Next(1000, 3000);
            client = new SimpleTcpClient("127.0.0.1:8888");
            client.Events.Connected += Events_Connected;
            client.Events.DataReceived += Events_DataReceived;
            client.Events.Disconnected += Events_Disconnected;
            button2.Enabled = false;
        }

        private void Events_Disconnected(object sender, ConnectionEventArgs e)
        {
            this.Invoke((MethodInvoker)delegate
            {
                button2.Enabled = false;
                button3.Enabled = true;
                textBox3.ReadOnly = true;
                textBox1.ReadOnly = false;
                button1.Enabled = false;
                textBox2.Text += $"Disconnected{Environment.NewLine}";
                textBox1.Text = Nickname;
                IPClient.Items.Clear();
            });
        }

        private void Events_DataReceived(object sender, DataReceivedEventArgs e)
        {
            this.Invoke((MethodInvoker)delegate
            {
                string Decoderdata = Encoding.UTF8.GetString(e.Data.Array, 0, e.Data.Count);
                if (Decoderdata == "!")
                {
                    IPClient.Items.Clear();
                }
                if (Decoderdata.EndsWith("/"))
                {
                    string Online = Decoderdata.Substring(0, Decoderdata.IndexOf('/'));
                    IPClient.Items.Add(Online);
                }
                else
                textBox2.Text += $"{Decoderdata}{Environment.NewLine}";
            });
        }

        private void Events_Connected(object sender, ConnectionEventArgs e)
        {
            this.Invoke((MethodInvoker)delegate
            {
                textBox2.Text += $"Connected{Environment.NewLine}";
            });
        }

        private void button3_Click(object sender, EventArgs e)
        {
            var strWithoutSpaces = textBox1.Text.Replace(" ", "");
            if (strWithoutSpaces != "" && textBox1.Text.Length > 4)
            {
                Connect();
                Nickname = textBox1.Text;
                textBox1.ReadOnly = true;
            }
        }
        async Task Connect()
        {
            await Task.Run(() =>
        {
            try
            {
                client.Connect();
                button2.Enabled = true;
                button3.Enabled = false;
                textBox3.ReadOnly = false;
                textBox1.ReadOnly = true;
                button1.Enabled = true;
                client.SendAsync(Nickname + "/");
                textBox1.Text += "#" + uif;
            }
            catch { textBox2.Text += $"Error Connected{Environment.NewLine}"; }
        });

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Disconnect();
            textBox1.ReadOnly = false;
        }
        async Task Disconnect()
        {
            await Task.Run(() =>
            {
                try
                {
                    client.Disconnect();
                    IPClient.Items.Clear();
                    button2.Enabled = false;
                    button3.Enabled = true;
                    textBox3.ReadOnly = true;
                    textBox1.ReadOnly = false;
                    button1.Enabled = false;
                }
                catch { Application.Exit(); }
            });

        }

        private void IPClient_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
